
let firstName = "Derek"
let lastName = "Pistorius"
var age = 37
let birthDate = 3/9/1985
var wandLength = "9 Inches"
var house = "Gryffindor"
var trait = "Brave"
var tiredOfHarryPotterRef = "No"

var goldInVault = 150.0
var afterFirstWand = goldInVault - 24.3
goldInVault = afterFirstWand
var afterMadamMilkin = goldInVault - 45.0
goldInVault = afterMadamMilkin
var afterGoblinGift = goldInVault + 300
goldInVault = afterGoblinGift
var afterWizardDice = goldInVault * 2
goldInVault = afterWizardDice
var afterBorginAndBurkes = goldInVault * 0.10
goldInVault = goldInVault - afterBorginAndBurkes
print(goldInVault)

let owlFromEyelops = "Black Beak, White Feathers" //enter in format "color beak, color feathers. This is case sensative
if owlFromEyelops == "Black Beak, White Feathers" {
    print("This one's mine!")
} else {
    print("Pass")
}

let favoriteQuidditchTeam = "White" //please enter team name in this format (case sensative) The Holyhead Harpies
if favoriteQuidditchTeam == "The Holyhead Harpies" {
    print("I only buy my Brooms if they are sponsored by The Holyhead Harpies")
} else {
    print("Sorry, I only buy Brooms that are sponosored by The Holyhead Harpies")
}


let student = "Wit" //Enter trait here in this format "Wit"

if student == "Cunning and Ambitious" {
    print("You are going to Slytherin!")
}
if student == "Brave" {
    print("You are going to Gryffindor!")
}
if student == "Loyal" {
    print("You are going to Hufflepuff!")
}
if student == "Wit" {
    print("You are going to Ravenclaw!")
}


let fizzingWhizzbeeCost = 2


func iBoughtFizzingWhizzBees (a: Int) -> Int {
    let totalCost = a * fizzingWhizzbeeCost
    return Int(goldInVault) - totalCost
}
iBoughtFizzingWhizzBees(a: 10)

let chocolateFrogCost = 3

func howManyFrogsPoss (familySize a: Int) {
        let frogCost = a * chocolateFrogCost
    if frogCost > Int(goldInVault) {
        print("No thanks, I'm all set")
              } else {
            print ("We'll take the lot!")
        }
    
}
howManyFrogsPoss(familySize: 100)

//in Part Five you asked to use loops. Even though I am familiar with loops in Javascript the training for loops with Swift is after this section. Therefore I will be skipping this until I have done the official training for loops and arrays.
